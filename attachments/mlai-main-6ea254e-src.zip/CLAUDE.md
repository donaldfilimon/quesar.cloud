# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

`AGENTS.md` is the canonical repository-wide map: the boundaries between the
five apps, the root commands, and what each gate does and does not prove.
Read it first, then the guidance for the surface you are changing. Do not
duplicate their detailed instructions here.

| Surface | Read before editing |
|---|---|
| `apps/quasar-web` | `apps/quasar-web/AGENTS.md`, `apps/quasar-web/CLAUDE.md`, and `apps/quasar-web/infra/README.md` for OpenTofu |
| `apps/mobile` | `apps/mobile/AGENTS.md`, `apps/mobile/CLAUDE.md` |
| `apps/quasar` | `apps/quasar/README.md` — this app has no `AGENTS.md` or `CLAUDE.md` |
| `apps/website-app` | `apps/website-app/AGENTS.md`, `apps/website-app/CLAUDE.md`, and `apps/website-app/README.md` |
| `apps/research-sites` | `apps/research-sites/AGENTS.md`, `apps/research-sites/CLAUDE.md` (generated export; never hand-edit `public/`) |
| `packages/*` | that package's own `README.md`; `packages/trailer-engine` has none, so read its `src/index.ts` exports |

`apps/quasar-web` is the canonical production Next.js website; `apps/website-app` is
the independently configured local Next.js application. Other trees
by that name exist elsewhere on this machine (`~/CLAUDE.md` maps them), so
confirm which one a request means before editing.

## Root commands

The root is orchestration only. These are the scripts it owns; anything more
specific belongs to an app and runs from that app's own directory. Use Bun
1.4, never npm, pnpm, or yarn.

```bash
bun run install:all      # bun install at the root: every workspace, one bun.lock (non-frozen)
bun run check            # check:topology, check:workflows, check:tooling, then web, then mobile, then quasar, then website-app, then research-sites
bun run check:topology   # bun packages/tooling/src/check-topology.ts
bun run check:workflows  # pinned Actionlint 1.7.12 via Go (requires Go 1.25+)
bun run check:tooling    # repository wrapper regression tests
bun run check:web        # cd apps/quasar-web && lint && test && build
bun run check:mobile     # cd apps/mobile && typecheck && test && lint && expo export
bun run check:quasar     # apps/quasar typecheck && test, then export:web in apps/quasar/apps/quasar
bun run check:website-app # isolated data wrapper: db:migrate, then check
bun run check:research-sites # cd apps/research-sites && bun test && build (manifest-verified)
bun run dev:web          # also dev:mobile, dev:quasar, dev:website-app
```

`AGENTS.md` (*Gate boundaries*) records what each gate does and does not
prove, plus how to focus a single test in each app. Read it before reporting
any gate result: a green web gate is not mobile evidence, a green Expo export
is not a signed CloudKit run, and no local gate is a hosted deployment.

## Cross-app facts

Each of these takes several files to reconstruct, so they are recorded here
rather than inside one app's docs.

- **One root Bun workspace, isolated linker.** Every app except
  `apps/research-sites` and the Quasar template installs from the root
  `bun.lock`; `bunfig.toml` sets `linker = "isolated"`. Install at the root,
  never inside an app (there are no app lockfiles, and `check:topology`
  rejects them). Only declared dependencies resolve, so an import that worked
  through another package's dependencies fails; declare it. The Next and Expo
  apps still use different React types: the root `package.json` pins the Next
  side's `@types/react`, `bunfig.toml`'s `hoistPattern` makes undeclared
  `react` type imports fall through to that pin, and each Expo app typechecks
  through its `tsconfig.typecheck.json`, which maps `react` to its own SDK 53
  types. `AGENTS.md` explains both; keep both.

- **The test runner differs per app, and the wrong invocation fails quietly.**
  `bun run test` is Vitest in `apps/quasar-web` and Jest in `apps/mobile`; a bare
  `bun test` in either one invokes Bun's own runner instead and does not run
  the suite you meant. `apps/quasar` is the exception: its `test` script
  genuinely is `bun test packages`.
- **`check:topology` requires this file to exist.**
  `packages/tooling/src/check-topology.ts` lists root `AGENTS.md`,
  `CLAUDE.md`, and `README.md` among its required paths, so renaming or
  removing one fails the first gate in `bun run check`. Beyond required paths
  it only rejects app lockfiles, nested `workspaces` fields and a non-isolated
  linker; it compiles no contracts and validates no content.
- **`@mlai/contracts` is a type-only vocabulary shared by two apps.** Web and
  mobile each consume it through a `workspace:*` dependency,
  and every use in app source is an `import type`
  (`apps/quasar-web/src/components/site/accent.ts`,
  `apps/mobile/lib/brand.ts`, `apps/mobile/lib/theme.ts`).
  `@mlai/design-tokens` holds the five raw Lab hex colors (`labColor`) and is
  a **runtime** import in both Expo `lib/theme.ts` files, so a change there
  reaches mobile and Quasar. Web keeps the same values in `src/index.css`;
  `apps/quasar-web/src/__tests__/design-tokens.test.ts` fails if the two drift, so
  change both together and run `check:web`, `check:mobile` and
  `check:quasar`. Semantic tokens stay app-local. `@mlai/trailer-engine` is
  the shared package with the most runtime code: `apps/quasar-web` depends on it via
  `workspace:*`, it exports raw `.ts` source, and the
  film/trailer code in `apps/quasar-web/src/film` and `apps/quasar-web/src/abbey-trailer`
  plus their `film-*`/`abbey-trailer` tests import it. A change there is web
  behavior, so run `check:web`, not only `check:tooling`.
- **A green local `bun run check` does not prove CI's install step.**
  `.github/workflows/ci.yml` runs topology, web, mobile, quasar, website-app,
  and research-sites as six independent jobs. The four app jobs with
  dependencies each run a frozen install at the repository root, filtered to
  `@mlai/platform` plus their own workspaces (research-sites has no install
  step by design), and the topology job runs
  `bun install --frozen-lockfile --lockfile-only` as the drift check, while
  `install:all` is deliberately non-frozen. Lockfile drift therefore surfaces
  in CI, or locally only if you run that same command.
- **`apps/quasar-web/site/` is a separately published artifact, not a build output.**
  GitHub Pages publishes it from `.github/workflows/pages.yml` with Actions as
  the source; the legacy `gh-pages` branch is retired and must not be
  recreated. Some brand assets exist in both `apps/quasar-web/public/` and
  `apps/quasar-web/site/`, and regenerating the `public/` copies does not touch the
  `site/` ones.

<!-- machine-git-policy -->
## Git workflow (machine policy, 2026-08-27)

Work on the default branch in this canonical checkout. Do not create
branches or worktrees by default; they are for tasks that genuinely need
isolation, or when Donald asks. Any worktree or topic branch created here
must be merged back into this checkout's default branch, the worktree
removed, and the branch deleted, before pushing and before the task is
called done. Full policy: `~/.claude/CLAUDE.md` (*Git discipline*).
<!-- /machine-git-policy -->
