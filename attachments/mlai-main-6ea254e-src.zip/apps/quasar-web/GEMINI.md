@./skills/ai-tooling-sync/SKILL.md

# Quesar by MLAI

This application lives at `apps/quasar-web/` in the MLAI integration repository. Run app-local commands here or use `bun run check:web` at the repository root; web-specific OpenTofu lives under `infra/`.

## Project Context
Production website and invite-only private AI operations console for Quesar by MLAI. **Next.js 15 App Router + React 19 + TailwindCSS v4, run on Bun** — one process serves pages and `/api/*` route handlers for WorkOS organization access, Gemini through Cloudflare AI Gateway, consent/audits, inquiries, telemetry, and admin reads.

The previous Vite SPA, Hono server, and Rust/Axum migration plan are abandoned. Do not extend or restore those stacks; active work belongs in TypeScript/TSX under `app/` and `src/`.

## Essential Commands
- `bun install` — Run from the repository root; every app shares the root `bun.lock`
- `bun run dev` — Next.js dev server on port 3000
- `bun run lint` — Type-check with `tsc --noEmit`
- `bun run test` — Vitest suite
- `bun run build` — Regenerate sitemap, then `next build`
- `bun run start` — Production `next start` on port 3000
- `bun run crawl` — Real-browser link-integrity crawl (`scripts/crawl-links.mjs`), needs a dev server or `BASE_URL=`
- `bun run design-sync:css` — Compile `src/index.css` → gitignored `.design-sync/lab-compiled.css` for the design-sync converter (`scripts/design-sync-css.mjs`)
- `bun run smoke` — API contract matrix; `SMOKE_WRITE=1` adds the inquiry write, `SMOKE_RATELIMIT=1` adds the csp-report 429 burst (oversize-body `413` cases run by default), `SESSION_COOKIE=mlai_session=…` adds the authenticated admin reads
- `bun run og` — Regenerate the static raster brand assets in `public/` (`python3` + `pillow fonttools brotli`); distinct from the per-slug Satori OG images `next build` emits. Refresh the duplicated `site/` copies too — the script does not.

## Critical Setup
- Copy `.env.example` to `.env`
- Required production secrets live in Google Secret Manager: WorkOS credentials, `SESSION_SECRET` (**≥32 chars**), Cloud SQL password, Cloudflare AI Gateway token, audit pepper, Turnstile secret, and `ADMIN_EMAILS`
- Stable `gemini-3.7-flash` is fixed behind the authenticated Cloudflare AI Gateway; payload logging and caching are disabled and there is no direct provider bypass
- Admin reads use `ADMIN_EMAILS`; `ADMIN_REQUIRE_MFA=true` adds fail-closed organization and signed-`auth_time` freshness checks, plus either a verified WorkOS TOTP policy/factor for non-SSO users or a separately attested IdP-MFA policy for SSO users
- Requires Bun 1.4+ (`packageManager: bun@1.4.2`)

## Architecture Overview
- **Frontend**: App Router files in `app/` render client views from `src/views/` via per-route `app/<route>/client.tsx` re-exports. Never recreate `src/pages/`. `client.tsx` is a plain re-export for standard routes, but a `next/dynamic(..., { ssr: false })` wrapper for browser-only views (`/showcase/*`, `/tf-pose-demo`).
- **Routing register**: every route needs a `routeMetadata` entry in `src/lib/route-meta.ts`, but it belongs in `scripts/generate-sitemap.ts` **only if it is not `noindex`**. The six `noindex: true` routes (`/login`, `/signup`, `/console`, `/profile`, `/financial-model`, `/tf-pose-demo`) are deliberately absent from the sitemap — that is the invariant, not drift.
- **Backend**: Next route handlers in `app/api/*`; shared server logic in `src/lib/server/` for sessions, PostgreSQL/Cloud SQL, WorkOS, consent, KMS-wrapped audits, rate limits, Turnstile, Gemini gateway calls, and POST body caps. `/api/auth/signup` intentionally redirects to request access; do not restore open self-provisioning.
- **POST body caps**: Next 15 route handlers have **no** default body cap (`bodyParser` is Pages Router only; `bodySizeLimit` is Server Actions), and Cloud Run's ceiling is 32 MB — so every POST reads through `src/lib/server/body-limit.ts`. Rate limiting caps request COUNT, this caps request SIZE; both are needed. `Content-Length` is a cheap early exit only (chunked requests omit it); the streaming byte counter is the guarantee. `readJsonLimited<T>` returns `T | Response` (413 oversize / 400 unparseable **or non-plain-object** / parsed value), narrowed with `instanceof Response`. Object SHAPE is guaranteed, FIELDS are still an assertion. The shape check matters: `null`/`5`/`"str"`/`true`/`[]` are valid JSON and used to throw outside each route's try/catch, so a `null` body was a public **500** on unauthenticated inquiries and telemetry. Aborted reads collapse to `null` instead of throwing — that is what keeps csp-report from ever 5xx-ing, pinned in `body-limit.test.ts`. Caps: 4 KB telemetry + billing/checkout, 16 KB profile, 32 KB inquiries, 64 KB csp-report, 128 KB llm/chat. Size a new route's cap to its real payload.
- **Auth/Admin**: `mlai_session` is an iron-session cookie. Protected generation requires active membership in the configured WorkOS organization and explicit versioned consent. Admin reads require `ADMIN_EMAILS` plus MFA; decrypted audit reads also require and log a reason.
- **Content**: `src/data/index.ts` aggregates `src/data/categories/*`. Blog and research entries are structured data with slugs and full bodies; do not hardcode long-form prose in components.
- **Two component layers**: `src/components/ui/` holds shadcn-style primitives; `src/components/site/` holds 24 section-level blocks (Section, CardPanel, StatBlock, ProvTag, FeatureCard, DataTable, …) built on them. Build page sections from `site/`. They hold no content (all props), require a provenance tag on figures (`measured | target | reported`), and carry no router dependency. Most take `accent?: "wdbx" | "abi" | "abbey"` → cyan/violet/emerald — **not** the persona axis, where Abbey is emerald, Aviva violet, Abi cyan.
- Performance figures require a reproducible repository harness and published methodology.
- **Design-sync barrel**: `src/components/ds.ts` is bundled for claude.ai/design. Nothing in it may transitively import `react-router-dom`/`next/*` — Next's client runtime reads `process.env.__NEXT_*` at module scope and throws in a standalone bundle, killing every export. `Logo` is excluded for this reason; `LogoMark` lives in its own router-free module.
- **Styling**: TailwindCSS v4 tokens/utilities live in `src/index.css`. Reuse `.container-custom`, `.container-prose`, `.section-y`, `.section-title`, `.glass-card`, and `.label-chip`.
- **Brand**: "Lab" system: cyan primary, blue/sky secondary, near-black ink canvas (`#05070d`), with violet/emerald/amber as fixed persona colors and a serif (Spectral) display face. The indigo "Signal" identity is retired; do not reintroduce indigo/fuchsia for brand chrome.
- **Showcase**: `/showcase/*` surfaces use lazy client chunks and cinematic engines under `src/film/`, `src/trailer/`, `src/mega/`, and `src/explainer/` — all four consume `src/film/`'s timeline engine and shared scenes, hosted by `src/components/CinematicShell.tsx`. `/showcase/design` renders the design lab in `src/design/` — real imported source, not one of the three similarly-named design-sync dirs (`.design-sync/` config+notes, partially tracked; gitignored `ds-bundle/` synced output; gitignored `.ds-sync/` npm staging, which also holds the Playwright install `bun run crawl` falls back to). Its `mlai-ds-tokens.css` is scoped under a `.mlai-ds` wrapper so it never leaks into `:root`, and `src/index.css` stays the canonical token source.
- **Neural voice**: `src/film/neural-voice.ts` (Kokoro-82M) must stay behind its lazy CDN dynamic import so it never enters the server bundle or the initial marketing chunk. Gesture-gated, honors `prefers-reduced-motion`, degrades to a silent caption.
- **Security headers / CSP**: the hand-curated CSP in `next.config.ts` reports violations to `app/api/csp-report/route.ts` via **both** `report-to csp-endpoint` and `report-uri` — keep both (Safari and older Firefox implement only `report-uri`). That endpoint logs to stdout and returns 204; it must **never** write to `telemetry_events`, whose contract is allowlisted event + pathname + timestamp with no identifiers, both fields passing through `telemetry-path.ts`'s allowlists. Unauthenticated on purpose, which is safe only because it is **rate-limited 60s/60 per client IP** (same window as `/api/telemetry`) — keep the guard as the handler's first statement, before the body read, and don't retune it to the tighter `inquiries` window. Extend the specific directive for a new origin; never widen to a bare `https:` wildcard.
- **OAuth `state` is CSRF-bound**: `base64url({nonce, returnTo})` matched against the `mlai_auth_state` cookie **before** the callback spends the code. Consequence to remember: **`APP_URL` and `FRONTEND_URL` must share a host** — the cookie is set by whichever host served `/api/auth/login`, so a `www.`-vs-apex split now fails every login with `invalid_state`. `getReturnTo` also rejects backslashes/C0 (`/\evil.com` resolves off-site), with a same-origin assertion at the sink.
- **`/benchmarks` carries architecture facts and interactive models only.** Any performance figure requires a reproducible repository harness and published methodology; provenance labels do not substitute for evidence.
- **Metadata defaults live in `toNextMetadata()`, not the layout** — Next's `mergeMetadata` REPLACES `openGraph`/`twitter`/`alternates`, so layout-only defaults meant the site shipped **zero** `og:image` and no feed autodiscovery. The layout copies stay live for `not-found`. Per-slug OG images survive because the default is gated on canonical path, not `ogType` (products sets none).
- **Production boundary**: `APP_URL=https://quesar.cloud` is required. OpenTofu owns regional-HA Cloud SQL, KMS, secrets, GitHub OIDC, the HTTPS load balancer, Cloud Armor's Cloudflare-only origin ACL, and the daily OIDC scheduler. Deployment uses an immutable image, dedicated runtime identity, Cloud SQL socket, load-balancer-only ingress, and a disabled `run.app` URL. Do not restore SQLite or `GCP_SA_KEY`.
- **Cloud Run deploy is gated on CI, not on push** — `deploy-cloudrun.yml` runs on `workflow_run` of *CI* and its `if:` is the trust boundary: success **and** `event == 'push'` **and** `head_repository.full_name == github.repository`, then it checks out the SHA CI validated. Keep all three; the `branches:` filter is only a pre-filter. `pages.yml` is gated the same way, with the same three conditions and a `head_sha`-pinned checkout, and still runs `landing-page.test.ts` before publishing. It has **no `paths:` filter** — `workflow_run` does not support one, and faking it by diffing `HEAD^..HEAD` would skip `site/` changes made in an earlier commit of a multi-commit push. The fork-identity check matters more here than on Cloud Run: `push:` was unreachable from a fork, `workflow_run` is not.
- **Shared parsing lives in `src/lib/dates.ts` and `src/lib/byline.ts`** — bylines are middle-dot joined (`"MLAI Research · WDBX Core"`); duplicate comma-only splitters in `route-meta.ts` and `structured-data.ts` each emitted one nonexistent author. Don't add a third copy.
- **`robots.txt` must not `Disallow` the noindex routes** — a blocked URL is never fetched, so the `noindex` is never seen, and it can still be indexed as a bare entry.
- **Performance**: Keep heavy route-specific dependencies isolated, especially TensorFlow on `/tf-pose-demo`.

## Verification
Run `bun run lint`, `bun run test`, and `bun run build` before production-impacting changes. Build regenerates `public/sitemap.xml`.

## Content Claims Constraint
External copy must not cite unsupported QPS, latency, accuracy, energy, benchmark, security, compliance, distributed-sharding, or scaling claims. Frame unverified metrics as targets and ground copy in implemented architecture.

For anything architectural, the sibling Rust substrate `~/dev/active/wdbx/crates/` is the authority — the mirrored `public/docs/wdbx/` snapshot is frozen Zig-era material with no live upstream, so its silence on a feature is missing documentation, not evidence the claim was invented (that inference was made once and the substrate refuted it: `hnsw.rs` and `mvcc.rs` are real). The real defaults are `M = 16`, `EF_CONSTRUCTION = 40`, and `EF_SEARCH = 32`; stale public `200` values were corrected on 2026-08-24 and pinned by `claims.test.ts`. `cluster_rpc.rs` disclaims sharding outright, so distributed-sharding copy stays forbidden.

`docs/master-reference.md` is the reconciled cross-project fact sheet and carries the provenance discipline this rule depends on: every metric is tagged **● measured** / **○ target** / **◆ reported**, and the three are never conflated. It also pins the standing Apple rule — only "Built on Apple's public frameworks (Metal, Accelerate, Core ML)" framing, no partnership or endorsement claim. Carry the tags forward when moving a figure into site copy. Tone rules live in `docs/voice-guidelines.md`.

## AI Tooling Sync
This project follows the global `ai-tooling-sync` skill. Keep `CLAUDE.md`, `AGENTS.md`, `GEMINI.md`, and README guidance aligned when changing durable instructions.

## MLAI Research Review Export

The approved corpus is structured under `src/data/categories/research.ts` and `research-records.ts`; `docs/research-inventory.md` records source revisions and dispositions. Keep summaries, capability labels, evidence references, limitations and attachment hashes in this content layer. The frozen Zig-era WDBX mirror is historical.

Run `bun run research:export --output /absolute/generated-site --generated-at <ISO-8601>` to produce the static review companion from the shared renderer. Export destinations must be empty (or contain only the initial Sites `.openai` scaffold) or be an existing generated research artifact. The manifest records canonical revision, export time, complete content and file hashes. Regenerate from a validated source revision; never maintain independent research prose in the generated project. Run `bun run test src/__tests__/research-artifact.test.ts` for export equivalence and destination safeguards.

The research review release stops at a validated canonical change set and owner-only Sites publication. Pushing the canonical deployment branch requires a later explicit public-rollout instruction.

## Public product journeys

`src/data/categories/product-journeys.ts` owns website navigation, product availability, setup links and intent paths. `/products` gives ABI, Abbey, WDBX and Quasar equal entry points; `/get-started` routes research, local Abbey, mobile and Quasar users to prerequisites and source setup. Product detail and research pages link reciprocally. Keep these records app-owned rather than moving copy into shared contracts. The standalone `site/` companion must use its own anchors and source links, with no dependency on deployed Next routes.

After the web gate, run `bun run verify:journeys --base-url http://127.0.0.1:3130 --static-url http://127.0.0.1:3131 --output /absolute/fresh-report-directory` against a running production build and a separate static server for `site/` (for example `python3 -m http.server 3131 --bind 127.0.0.1 --directory site`) for Chromium, Firefox and WebKit journey checks. Do not rebuild while this check or the crawl is running. Production CSP upgrades insecure requests in WebKit: use an HTTPS loopback reverse proxy for all-engine acceptance, and `--allow-self-signed` only for a temporary loopback certificate. This keeps CSP enabled. This browser check does not validate provider generation or native signed-device behavior.
