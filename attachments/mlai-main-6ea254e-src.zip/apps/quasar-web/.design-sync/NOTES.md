# design-sync NOTES — MLAI-CORPORATION-WWW

This repo is a **Next.js app**, not a packaged design system. The sync targets the repo's
de-facto design system, built in **synth-entry mode** (no shipped `dist`/`.d.ts`) from a
purpose-built barrel: `src/components/ds.ts`, which re-exports **two layers**:

- `src/components/ui/` — 16 shadcn-style primitives (Button, Card, Dialog, …)
- `src/components/site/` — 24 section-level blocks (Section, StatBlock, ProvTag, …),
  harvested 2026-08-08 from the "MLAI Design System" / "MLAI Site Design System" Claude
  Design projects and re-tokenized onto the Lab brand.

`componentSrcMap` enumerates the card-worthy components so sub-parts (CardHeader,
DialogTrigger, …) stay in the bundle for composition without becoming separate cards.

## Gotchas

- **NEVER let the DS bundle reach Next's client runtime.** This is the single biggest trap
  in this repo. `src/lib/router-compat.tsx` (the `react-router-dom` alias) imports
  `next/link` + `next/navigation`, which read `process.env.__NEXT_*` **at module scope**.
  In the standalone DS bundle there is no Next runtime, so that throws
  `ReferenceError: process is not defined` during the IIFE — which kills **every** export,
  not just the router-using one. Symptom: `[BUNDLE_EXPORT] N/N not a component on
  window.MlaiLab` plus `[RENDER] root empty` on components that have nothing to do with
  routing. Cost a full build cycle on 2026-08-08.
  - The converter already defines `process.env.NODE_ENV`; that is **not** enough — Next
    reads a dozen other `__NEXT_*` vars.
  - Consequences, both deliberate: `LogoMark` lives in its own router-free module
    (`src/components/LogoMark.tsx`) so it can ship, while `Logo` (which links to `/`) is
    **excluded from the DS** and stays app-only. `NextUp` and `PublicationIndex` render a
    plain `<a>` and take an optional `linkComponent` prop instead of importing the shim.
  - **Before adding any component to `ds.ts`, check its transitive imports for
    `react-router-dom` / `next/*`.**
- **CSS must be recompiled before every sync build.** There is no shipped stylesheet, so
  `[CSS_RUNTIME]` fires unless we compile one: `node .ds-sync/compile-css.mjs` runs the
  repo's own `@tailwindcss/postcss` over `src/index.css` → `.design-sync/lab-compiled.css`
  (~216 KB), which `cfg.cssEntry` points at. The emitted utility set is derived by scanning
  source, so **any component added or restyled changes it** — a stale file silently ships
  components whose classes don't exist. The script is staged into the gitignored `.ds-sync/`,
  so it is recreated from this note on a fresh clone (it is ~30 lines: postcss + tailwind
  over `src/index.css`, `from:` set to the real path).
- **playwright pin drifts — verify, don't trust this file.** The cached chromium build was
  **1228** (playwright 1.61.0) in the prior run and is **1234** (playwright **1.62.0**) as of
  2026-08-08. Check `~/Library/Caches/ms-playwright/` (macOS — *not* `~/.cache/ms-playwright`)
  and match the release whose `browsers.json` pins that build, then install into `.ds-sync`
  with `PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1`. A mismatch fails with
  `browserType.launch: Executable doesn't exist`.
- **Self-symlink loop**: `node_modules/mlai-corporation-www -> ..` (Bun-created) makes the
  converter's ts-morph `**/*.d.ts` glob recurse forever (ENAMETOOLONG). It was absent on the
  2026-08-08 run, but if a build dies with ENAMETOOLONG, `rm node_modules/mlai-corporation-www`
  and retry; `bun install` recreates it.
- **Fonts**: Geist (body sans) ships via `@fontsource`. Spectral (display serif, the Lab
  signature) + JetBrains Mono are Google-Fonts-served at runtime, so they are declared in
  `cfg.runtimeFontPrefixes` rather than shipped. If a future scope adds heading-heavy
  components, ship Spectral woff2 via `cfg.extraFonts` for full fidelity.

## Preview authoring conventions (this repo)

- **Wrap EVERY preview — both layers — in the Lab ink ground**:
  `<div style={{ background: "#05070d", padding: 28, borderRadius: 12 }}>`, hoisted to a
  module-level `const ink` per file with any `maxWidth` folded in.
  The converter's preview template hardcodes `body{background:#fff}` (`lib/emit.mjs` — do
  not fork it). This DS is **dark-only**, so without the wrapper `text-white` content is
  literally invisible: on the first 2026-08-08 capture FAQList rendered as an empty card,
  StatBlock's label line was absent entirely, and Accordion was near-illegible. Wrapping is
  the sanctioned fix and matches what the upstream mlai-site previews did.
  **A prior run recorded this as an accepted "known dark-canvas mismatch" — that framing is
  retired.** It is not a limitation to live with; it is a per-preview fix, and a preview
  missing it renders invisible rather than failing loudly, so it will not show up in any
  automated check. All 36 previews carry it as of 2026-08-08.

- **The ink object needs `color` and `fontFamily`, not just `background`.** The harness body
  sets `background:#fff` with **no `color`**, so text inherits black. A component that sets
  no text-color class of its own then goes from "black on white, washed out" to "black on
  near-black, **invisible**" — strictly worse. Use:
  ```js
  const ink = { background: "#05070d", color: "var(--foreground)",
                fontFamily: "var(--font-sans)", padding: 28, borderRadius: 12 };
  ```
  which reproduces `<body className="…text-text">` from `app/layout.tsx`. Verified
  color-inheriting primitives: **`ui/textarea.tsx`** (value text) and **`ui/label.tsx`**.
  `ui/input.tsx` sets `text-foreground` and is NOT affected — a batch report claimed
  otherwise; the grep is the authority. Most `site/` blocks set their own `text-*` classes
  and are unaffected, but include `color` anyway so the next component added can't regress.
- **Full-width compositions need `cardMode: "column"`.** Set for Section, SplitSection,
  DeepDive, StepList, DataTable, FAQList, Prose, Glossary, PublicationIndex, HeroBench,
  NextUp, SpecList. Without it, SplitSection's two-column sticky layout collapsed to a
  one-character-wide column of text in the grid cell.
- **Preview content is bound by the external-claims policy** (see `CLAUDE.md` and
  `docs/master-reference.md`). No invented QPS/latency/recall/speedup figures — the upstream
  components shipped several (`8.2ms p50`, `295×`, `95% recall`, a WDBX-vs-baseline table)
  and **none of them were carried over**. `StatBlock`/`ThroughputCard` require a provenance
  tag per figure; prefer countable facts or architecture facts.

### Capture-environment facts that shape what a preview can show

Folded from the 2026-08-08 four-batch preview run.

- **The capture viewport is 900×700 and `fullPage: false`** (`package-capture.mjs`), so
  anything past 700px is **silently clipped** — with `.section-y` (`py-20`) a band component
  lands near ~690px, so preview copy for `Section`/`SplitSection` has to stay short.
- **A wrapper `maxWidth` cannot trigger a `lg:` layout.** Tailwind breakpoints read the
  *viewport*, not the container. `SplitSection`'s two-column sticky layout (`lg:` = 1024px)
  and `DeepDive`'s `cols={3}` (`lg:grid-cols-3`) are both invisible at 900px — `Grid2` and
  `Grid3` rendered *identically*. The fix is `cfg.overrides.<Name>.viewport` (capture caps at
  2000); both now declare `"1280x900"`. Do **not** inject CSS to fake a layout the component
  doesn't actually produce at that width.
- **Previews must use inline `style={{}}`, not Tailwind classes.** `lab-compiled.css` is
  generated by scanning `src/` only, so a new utility class used in `.design-sync/previews/`
  gets no CSS at all and fails silently.
- **Grading must come last in the loop.** `preview-rebuild.mjs` clears a grade when a
  preview's contract changes, and an explicit `ov.viewport` is grade-keyed — so
  edit-all → rebuild → capture → *read the sheet* → grade.
- **`preview-rebuild.mjs` does not rebuild `_ds_bundle.js`.** A component whose *source* was
  fixed mid-session is still stale in the bundle, and previews get graded against the old
  behavior. This bit the `HeroBench` `animate` fix on 2026-08-08 (caught only by grepping the
  bundled function signature). After any source fix, run the full driver before final grading.

### Preview content rules learned the hard way

- **`src/data/categories/stats.ts` is NOT safe to lift preview copy from.** It is
  target-framed, but its entries are `295x`, `0.8ms`, `16.5k` — exactly the banned
  categories. Filter, never lift wholesale.
- **A bar is an assertion even with no number printed.** Every `ThroughputCard` row's `fill`
  must be proportional to the countable thing in its `value`; a persona-routing ladder with
  invented 0.42/0.34/0.24 fills was removed for implying a traffic split.
- **Provenance tags are easy to get wrong, including by the author of the component.** On the
  first pass a countable repo fact ("12 workspace crates") was tagged `target`, and a bare
  `O(log n)` was tagged `reported` with no citation. `measured` = countable/reproduced;
  `target` = a goal, say so in the note; `reported` = **cited**, so name the source.
- **Pair the accent with the layer the figure describes** — a retrieval figure carrying the
  `abbey` (agent-layer) accent reads as a miscategorization.
- **`LogoMark`'s `title` prop next to visible text is an a11y trap** — it double-announces.
  `Logo.tsx` omits it deliberately; only set `title` when the mark stands alone.

## Known render warns

- `[FONT_MISSING]` Spectral + JetBrains Mono — expected; the app serves them at runtime
  (`cfg.runtimeFontPrefixes`). The primitives render in Geist (shipped).
- **Floor cards (4, deliberate)**: Dialog, DropdownMenu, Toaster, Tooltip. Base UI portals
  their open state to `document.body`, so the open panel escapes the card, and hand-drawing
  a static lookalike is disallowed. Authorable if Base UI gains an inline/`keepMounted`
  render path, or via a portal-container override.

## Re-sync risks — what can silently go stale

1. **`lab-compiled.css` is generated and gitignored.** Regenerate it every run (above). If
   it is missing, `cfg.cssEntry` dangles and the bundle ships unstyled.
2. **`.ds-sync/compile-css.mjs` is gitignored too** — it is recreated from the description
   above, not restored from git. Consider promoting it into the durable set if it keeps
   being needed.
3. **The router trap re-arms itself.** Any new `site/` component that imports a link, or any
   refactor that pulls `router-compat` into an existing one, silently breaks the *entire*
   bundle. The failure looks unrelated to routing — read the first gotcha before debugging.
4. **playwright/chromium pin drifts with the machine's cache**, as it already did once.
5. **Preview grades follow their sources**, so the authored `.tsx` files and preview-affecting
   config carry forward; styling/bundle churn does not invalidate them. A `grade cleared` on a
   no-change run means a nondeterministic input — chase it.
6. `Logo` is deliberately absent from the DS (router). If someone "fixes" that by adding it
   back to `componentSrcMap`, the whole bundle dies — see gotcha 1.
7. **The ink-ground wrapper is a workaround repeated in all 36 previews.** Four independent
   batches converged on the same durable fix, and one located it exactly:
   `lib/emit.mjs:133` — `body{margin:0;padding:24px;background:#fff}` on the per-card preview
   document. `styles.css` is already linked there, so `background: var(--background)` would
   resolve to the real token with no new config key; the same string recurs at `emit.mjs:210`
   and `:516`, and two sibling light-theme constants on that template need the same pass
   (`.ds-cell{border:1px solid #e5e7eb}`, `.ds-cell>h4{color:#6b7280}`). Do **not** touch
   `package-capture.mjs:209` — that is contact-sheet chrome whose black label text depends on
   the white ground.
   **Still not implemented here, deliberately, for two reasons:** the skill names
   `lib/emit.mjs` as defining the output contract with the app's self-check and says not to
   fork it; and `.ds-sync/` is gitignored and re-copied from the skill on every run, so an
   edit there is silently reverted on the next sync. This belongs upstream in the converter.
   Until then every new preview must remember the wrapper, and a forgotten one renders
   invisible rather than failing loudly.
9. **`dark:` variants are dead in previews.** `src/index.css` defines
   `@custom-variant dark (&:is(.dark *))` and the app puts `.dark` on `<html>`, but the
   preview root has no such ancestor — so `dark:bg-input/30` (Input/Textarea/Select field
   fills) and Tabs' `dark:data-active:bg-input/30` never apply. Fidelity gap, not a blocker:
   everything still renders legibly. The fix is a decorator/provider stamping `class="dark"`
   on the preview root, which would cover all 36 at once — same upstream conversation as (7).
10. **`Skeleton`'s `animate-pulse` is not frozen during capture**, so its cell's brightness
   varies run to run. A washed-out Skeleton cell may be capture phase, not a defect; the real
   fix is playwright's `animations: 'disabled'`.
11. **`pendingGrade` needs a second capture pass to settle.** It is computed at capture time,
   before grades exist, and `resync.mjs` gates on `pendingGrade === false`. The carry-forward
   branch refreshes it without re-screenshotting or clearing grades — so after grading, run
   `package-capture.mjs` once more. The documented loop stops one step short of this.
8. **Open API gaps deliberately left open**: `Glossary` has no variant prop (single-axis by
   nature, fine); `DataTable`'s `highlightCol={0}` is a documented no-op rather than an error.
## Run log — `/design-sync MLAI` (this run)

**Config audit: clean.** All 16 `componentSrcMap` paths resolve, `entry`
(`src/components/ui/index.ts`) exists and re-exports every mapped module, and the
barrel's 17th export (`toast`) is correctly a sub-part of `Toaster`, not a 17th card.
No drift since the last sync.

**Fixed: the CSS compile step is now in-repo.** `cfg.cssEntry`
(`.design-sync/lab-compiled.css`) was *missing* — the recipe was documented above but
the script lived only in the external converter checkout (`.ds-sync/compile-css.mjs`),
so a fresh clone could not regenerate it and every sync would report `[CSS_RUNTIME]`.
It's now `scripts/design-sync-css.mjs` (`bun run design-sync:css`): runs the repo's own
`@tailwindcss/postcss` over `src/index.css`, self-checks that OKLCH tokens *and* real
utilities came out, and exits non-zero if not. Output is 208 KB (matches the ~203 KB
recorded previously) and is gitignored — regenerate, never hand-edit or commit.

**Found + fixed a real token bug (accessibility).** Diffing every utility used by the
primitives against the compiled sheet surfaced `text-destructive-foreground` (used by
`badge.tsx` and twice in `toast.tsx`) resolving to **nothing**: `--destructive-foreground`
was never defined in `src/index.css`. Tailwind v4 emits no rule for an undefined theme
color, so the destructive Badge/Toast text silently inherited the light `--foreground`
— **2.7:1** on the light-red `--destructive` (`#ff5352`), failing WCAG AA. Added
`--destructive-foreground: oklch(0.15 0.02 25)` (dark ink → **6.2:1**), mirroring the
documented `--primary-foreground` reasoning, and re-exposed it via `@theme inline` per
the "update both" rule. Both dead utilities now emit.

**Guarded going forward.** `src/__tests__/design-sync.test.ts` (41 assertions) pins the
config against the filesystem and asserts every semantic token used by the primitives is
both defined in `:root` and re-exposed as `--color-*`. Mutation-checked: deleting the
token fails 2 assertions.

**Previews unaffected.** The 12 authored previews use inline `style={{}}`, not utility
classes, so they carry no dependency on Tailwind's content scanning — a good property,
keep it. The 4 floor cards (Dialog, DropdownMenu, Tooltip, Toaster) remain floor cards
for the portal reason recorded above.

**Not run here:** the converter itself (bundling, Playwright capture, card upload) — that
toolchain is external to this repo and unavailable in this environment. Everything above
is the repo-side half: config integrity, the compiled `cssEntry`, and the token fix the
capture would otherwise have rendered wrong.


## Retargeted to "MLAI Design System" (2026-08-20)

`projectId` moved from `c535eba1…` ("MLAI Lab UI Primitives") to
`6d97fa83-1224-4573-9c22-46f67ac46f3c` ("MLAI Design System") on Donald's explicit call:
one project is to hold both this repo's components and the mobile-app design layer
(8 `preview/mobile-*.html` cards + 6 `guidelines/` docs) synced there earlier the same day.

**Upload is WRITES-ONLY for this consolidation — no reconciliation deletes.** The target is
non-empty and holds material this repo does not produce (the mobile layer, `uploads/`, the
vision-trailer template, `Canvas.dc.html`). The standard reconciliation pass deletes every
remote path a sync's own bundle doesn't contain, which would destroy all of it. Merge intent
beats tidiness here; the cost is that genuinely stale files from earlier syncs linger.
If a future run wants the tidy behaviour, it must first confirm the non-repo material is
expendable — do not re-enable deletes silently.

**Converter availability changed.** The previous run recorded the converter toolchain as
"external to this repo and unavailable in this environment"; it is available now (shipped
with the design-sync skill), so an end-to-end build/verify/upload is possible for the first
time. Playwright is staged into the gitignored `.ds-sync/` and driven against the installed
Google Chrome via `DS_CHROMIUM_PATH`, so no browser binary is downloaded into the repo.

## First end-to-end run (2026-08-20) — what bit, and what to do next time

**Self-referential symlinks break the `.d.ts` walk. This is the trap of this repo.**
`lib/dts.mjs` globs `${root}/**/*.d.ts` with a `!**/node_modules/**` negation, but the
negation only *filters results* — fast-glob still **traverses**. This repo has npm
self-reference links (`<pkg>/node_modules/<pkg> -> ..`) which make traversal infinite; the
build dies with `ENAMETOOLONG: scandir` on a path repeating the package name ~25 times.
`root` is the repo root here because synth-entry mode has no `types` field to narrow it
(`findTypesRoot` falls through to `pkgDir`).

Two existed:
- `design-sources/variants/mlai-operating-system/node_modules/mlai-operating-system -> ..`
  — **deleted permanently**. `design-sources/` is gitignored with zero tracked files, and the
  link is npm-generated, so nothing was lost. It will come back if that scratch package is
  reinstalled.
- `node_modules/mlai-corporation-www -> ..` — the repo's OWN self-link. **Do not delete
  it**; npm manages it and app code may self-import. The build recipe is to unlink it, build,
  and restore it in the same command so it is restored even on failure:
  ```sh
  SL=node_modules/mlai-corporation-www; HAD=0
  [ -L "$SL" ] && unlink "$SL" && HAD=1
  node .ds-sync/package-build.mjs …; EXIT=$?
  [ "$HAD" = 1 ] && ln -s .. "$SL"
  exit $EXIT
  ```
  A cleaner permanent fix would be a `libOverrides` fork of `dts.mjs` that skips symlinked
  dirs, or a `publishConfig.types` narrowing `root` to `src/` — neither was needed to ship.

**Interactive `rm` — CORRECTED 2026-09-06, and the correction reverses the risk.** This note
used to say the shell aliases `rm` to `rm -i`, so a tty-less delete *silently skipped and still
exited 0*. That is **no longer true**: `~/.zshrc` was replaced with a stock oh-my-zsh template on
2026-09-02 and none of `~/.zsh/*.zsh` is sourced, so `rm` and `cp` carry **no alias** and
`noclobber` is **unset** (verified in a clean login shell). The old failure mode was a silent
no-op; the current one is a **real delete**, and `cmd > existing-file` now truncates instead of
failing. Write destructive steps defensively against both shells: `command rm -f`, `>|` for a
deliberate truncate, and verify by reading the path back rather than trusting an exit code.

**No browser download needed.** `package-capture.mjs` honours `DS_CHROMIUM_PATH`; pointing it
at `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome` avoids Playwright's
chromium download. npm's blocked install-scripts warning for esbuild was benign — the binary
loaded fine.

**Result.** Build clean (40 components, 988 KB bundle, 36 authored previews reused, 4 floor
cards as documented). `package-validate.mjs` exit 0: 40/40 previews render, anchor matches
disk, styles.css closure resolves, 2 tokens missing (below threshold). Uploaded 216 files.

## Re-sync risks (watch-list for the next run)

- **The upload was WRITES-ONLY** (see the retarget section). The target therefore still holds
  files this repo does not produce and which no diff will ever reconcile: `components/lab/**`,
  `components/site/{Footer,Logo,Nav}`, `components/vendor/**`, `vendor/**`, `_ds/**`,
  `colors_and_type.css`, `_ds_manifest.json`, `SKILL.md`, `preview/**`, `assets/**`,
  `ui_kits/**`, `templates/**`, `uploads/**`. Some are genuinely stale prior-sync output
  (`components/lab/**` duplicates `components/general/**`); the rest is the deliberately
  preserved mobile/design layer. Cleaning the stale half requires an explicit decision — do
  not infer it from a diff.
- **The anchor now in the project describes THIS build.** Next re-sync can diff against it
  normally; the styleSha will change whenever `bun run design-sync:css` output changes, which
  re-verifies everything.
- **`.design-sync/lab-compiled.css` is gitignored and MUST be regenerated** before every build
  (`bun run design-sync:css`) — a stale one silently ships classes that don't exist.
- **Assumed toolchain**: node 26.7, bun 1.4, converter staged into `.ds-sync/` from the
  design-sync skill. The skill's scripts change; re-copy them every run rather than trusting a
  stale `.ds-sync/`.

## Re-sync verification run (2026-08-22) — clean no-op, and two facts worth keeping

`src/` was unchanged since the first end-to-end run, and the driver confirmed it end to end:
`resync.mjs --remote` → build ok, diff ok, validate exit 0, capture **skipped
(`empty_worklist`)**, `anchor: "ok"`, **40/40 unchanged**, `upload.any: false`. Nothing
uploaded, nothing re-graded, no canary. A verdict shaped like that is the expected result of
a no-change re-sync, not a failure — read `ds-bundle/.resync-verdict.json` before assuming
otherwise.

- **The pipeline is byte-deterministic. Measured, not assumed.** `bun run design-sync:css`
  regenerated `lab-compiled.css` **byte-identical** (sha256 `2069e897…`), and the freshly
  built `ds-bundle/_ds_sync.json` **diffs clean against the anchor fetched from the project
  before the run** — same `styleSha 475ddc…`, same `bundleSha12 ca9d43de3db8`, all 40
  `renderHashes`/`sourceKeys` identical. That is the direct proof, not an inference from the
  verdict's `upload.any: false`; reproduce it with
  `diff .design-sync/.cache/remote-sync.json ds-bundle/_ds_sync.json`. This **closes the "styleSha will change whenever the CSS output changes,
  which re-verifies everything" worry** in the risks list above: it does not churn on its own.
  A styleSha change from here means a real source or config change. Practical consequence: a
  no-change re-sync costs ~2 minutes, so there is no reason to skip one.
- **`cp` is aliased to `cp -i`, exactly like `rm`.** The gotcha above records the `rm` case;
  `cp` bites the same way and the re-stage step is where it lands. With no tty the copy
  **silently refuses and still exits 0** ("not overwritten" per file), so a stale `.ds-sync/`
  survives a `cp -r` that looked like it worked — meaning the *old* converter runs against
  the *new* instructions. Use `command cp -rf`. Verify with
  `diff -rq "<skill-base-dir>/lib" .ds-sync/lib` (must be empty).
- **`tokens/` in the output is empty by design here** — this DS has no separately scraped
  token files; every token lives in the compiled `_ds_bundle.css`, which `styles.css`
  `@import`s. The closure is 57 B `styles.css` → 216 KB `_ds_bundle.css` + 1.6 KB
  `fonts/fonts.css`. Not a missing-tokens defect.
- **`conventions.md` re-validated against the fresh build: zero drift.** All 21 utility
  classes, 11 tokens, 40 component names, the compound parts, `linkComponent`/`personas`/
  `accent`, and every Button/Badge/Alert variant it names still resolve. Re-run that check
  rather than trusting this line — it is only true of the build it was run against.
- **Stale remote paths are unchanged and still not cleaned** (see the watch-list above);
  the re-run of `/design-sync` was NOT treated as authorization to enable deletes.

### Stale-path cleanup (2026-08-22) — the writes-only debt, partly paid

On Donald's explicit go-ahead, **85 enumerated paths** were deleted from the project. The
plan listed every path literally — **no `components/**` or `guidelines/**` glob** — because
the standard reconciliation globs would take the preserved mobile/design layer with them.
That constraint is permanent while this project holds non-repo material; re-read the
retarget section before any future delete.

Deleted: `components/lab/**` (16 primitives × 4 files — duplicates of the current
`components/general/**`), `components/site/{Footer,Logo,Nav}/**` (12), `components/vendor/**`
(LabRuntime + SiteRuntime, 6), `_preview/{Footer,Logo,Nav}.js` (3). Sequence was sentinel →
deletes → sentinel re-arm; `_ds_sync.json` was left untouched because none of these paths
are in the anchor, so it never described them.

Confirmed intact after the pass: all 6 `guidelines/`, all 24 `preview/*.html` (the 8
`mobile-*` cards included), `uploads/**`, `templates/vision-trailer/**`, `ui_kits/**`,
`vendor/**`, `_ds/**`, `assets/**`, and the app-regenerated `_ds_manifest.json` +
`_adherence.oxlintrc.json` — those last two come from the self-check, not from `ds-bundle/`,
so a naive "not in my bundle → delete" rule would wrongly sweep them.

**Two stale items found during the pass and deliberately NOT deleted** (outside what was
approved; both safe to remove whenever someone says so):
- `components/site/LogoMark/**` — the current build emits LogoMark under `general` only, so
  the `site` copy is orphaned prior-sync output.
- `_preview/{Dialog,DropdownMenu,Toaster,Tooltip}.js` — leftovers from a sync when those had
  previews. They are floor cards now, and floor-card HTML references no `_preview/` file
  (verified by grep), so nothing points at them.

## Re-sync run (2026-09-06 17:0x) — Sheet added, uploaded writes-only

`resync.mjs --remote` → build ok, diff ok, validate **exit 0**, capture skipped
(`empty_worklist`), `anchor: "ok"`, `learningsUnmerged: []`. Verification: **40 unchanged,
1 added (`Sheet`), 0 removed, `pendingGrade: []`**. Render check **41 total, 0 bad, 0 thin,
0 variantsIdentical**. Uploaded 221 files (219 content + sentinel + anchor), **0 deletes**.

- **`Sheet` is new since the 2026-08-22 anchor** and ships as a **floor card**, joining
  Dialog, DropdownMenu, Toaster and Tooltip — five now, not four. Same Base UI portal reason:
  it has no authored preview, and `fallbackCard: true` with `rootEmpty: false` and 19 KB of
  PNG is the honest baseline, not a failure. Authorable whenever someone wants it.
- **⚠️ NEW DURABLE TRAP, and it fails silently toward 40x the work: a hand-written
  `remote-sync.json` that omits `sourceHashes` is rejected WHOLESALE.** The driver prints one
  line — `! remote sidecar malformed — treating as no anchor` — and proceeds to
  `full scope (41 component(s) verify + upload)`. It does not error, does not exit non-zero,
  and the run looks normal. Because `.design-sync/.cache/review/` is gitignored and was
  **empty on this machine**, full scope meant capturing and hand-grading all 41 instead of
  the 1 that actually changed. The envelope needs `sourceHashes` (120 entries here: 3 files ×
  40 components), not just `renderHashes`/`sourceKeys`. If you transcribe an anchor by hand,
  validate it against the freshly built `ds-bundle/_ds_sync.json` before trusting the scope
  line — all 40 renderHashes, 40 sourceKeys and 120 sourceHashes matched exactly, which is
  what proved both the transcription AND that the 40 were genuinely unchanged.
- **Determinism held again, measured not assumed.** `bun run design-sync:css` regenerated
  `lab-compiled.css` byte-identical (sha256 `f33fea44…` before and after). `styleSha` DID
  move against the 08-22 anchor, which is correct: today's `442c7bc` changed the CSS step.
  Per the 08-22 note, a styleSha change from a stable baseline means a real source or config
  change, and this one is exactly that.
- **playwright pin re-verified, and the drift note can be updated:** the cache now holds
  chromium **1234 and 1243**; playwright **1.63.0** pins 1243, so installing that exact
  version into `.ds-sync/` matched with no browser download and no `DS_CHROMIUM_PATH`
  needed. (Prior runs recorded 1228/1.61.0 then 1234/1.62.0 — it drifts every time; always
  read `browsers.json` rather than trusting any version written here.)
- **`conventions.md` re-validated against the fresh build: zero drift.** All 28 component
  names, 14 utility classes and every token it declares still resolve in `_ds_bundle.css` /
  `_ds_bundle.js`. **Proposed edit, deliberately NOT applied** (the file is authored, and the
  skill says validate rather than rewrite): it does not mention `Sheet`. Worth a line next
  time someone edits it.
- **`[TOKENS_MISSING]` is now 5, up from 2** — `--accordion-panel-height`, `--available-height`,
  `--anchor-width`, `--transform-origin`, `--tw`. All are Base UI / Tailwind values set at
  runtime by the component itself, which the warn text itself calls expected. Non-blocking,
  and now on the known-warns list so a future run does not read it as new.
- **The self-symlink was absent this run**, so the unlink/restore dance was not needed. It
  returns with `bun install`; the recipe above still stands.
- **Two stale paths the 08-22 pass listed as "found but not deleted" are already gone** from
  the project: `components/site/LogoMark/**` and `_preview/{Dialog,DropdownMenu,Toaster,Tooltip}.js`
  are absent from `list_files` both before and after this run. Nothing here deleted them —
  **this run issued zero deletes** — so they went in some other pass. The writes-only rule
  was honored: `deletePaths` was `[]` from the diff independently of the policy.

### Re-sync risks (updated watch-list)

- The writes-only constraint stands and is unchanged. `preview/mobile-*.html` (8),
  `guidelines/` (now **7** — `research-inventory.md` joined), `uploads/`, `ui_kits/`,
  `templates/vision-trailer/`, `vendor/`, `_ds/`, `assets/`, `colors_and_type.css` and
  `SKILL.md` were all confirmed present after this upload. Do not enable reconciliation
  deletes without re-confirming that material is expendable.
- **Grades are gone on this machine** (`.design-sync/.cache/review/` empty). That is fine
  while the anchor is valid, because unchanged components skip grading entirely — but it
  means any run that loses the anchor pays the full 41-component grading cost. The anchor is
  the only thing standing between a 2-minute re-sync and an hours-long one.

## dts override ported here (2026-09-06 19:1x) — BUILT AND VERIFIED, NOT YET UPLOADED

`.design-sync/overrides/dts.mjs` is the fork proven on `donald-filimon-sites` the same
evening. It fixes the fact that **every component here shipped
`<Name>Props { [key: string]: unknown }` as its entire API contract** — which is precisely
what the Claude Design agent codes against. Upstream computes the ts-morph entry as
`pkgDir/<pkg.types || index.d.ts>` and globs only `**/*.d.ts`; this repo ships neither, so
prop extraction found nothing. The fork changes three things: entry falls back to
`cfg.entry` (`src/components/ds.ts`), the project also loads `srcDir`'s real `.tsx`, and
`baseUrl`/`paths` come from `cfg.tsconfig`.

**Result, measured:** `ButtonProps` now carries the full `variant` and `size` unions,
`asChild`, and the inherited Base UI props with JSDoc. `StatBlockProps` is
`{ stat: Stat; accent?: "wdbx" | "abi" | "abbey"; className?: string }` with the
provenance-tag constraint in its doc comment. **39 of 40 emitted `.d.ts` changed.**
Build exit 0, validate **exit 0**, "all .d.ts parse cleanly".

**The router trap did NOT re-arm, and that was checked deliberately.** `tsconfig` maps
`react-router-dom` to `src/lib/router-compat.tsx`, whose `next/link` import reads
`process.env.__NEXT_*` at module scope and would kill every export. That failure is a
BUNDLING one; this fork feeds only ts-morph, never esbuild. Verified after the build:
`window.MlaiLab: 109 exports (41 fn + 0 compound)`, byte-identical to before, and
41/41 previews still render with the same 5 floor cards.

**⚠️ Why this is not uploaded yet, and what it will cost.** **CORRECTED: it is the fork
FILE, not the `cfg.libOverrides` declaration, that moves the keys.**
`lib/sync-hashes.mjs:141-146` says `cfg.libOverrides` is *deliberately* not keyed - "its
values are declaration prose with no render effect" - and then hashes **every `.mjs` under
`.design-sync/overrides/` by its bytes**, because a lib fork genuinely can change rendering
and the tool cannot know that this one does not. So dropping the declaration would not
avoid the churn; it would only trip `[OVERRIDE_UNDECLARED]`. The effect: **all 40
`sourceKeys` changed**, and 3 `renderHashes` moved as well (Dialog, DropdownMenu, Tooltip
— floor cards embed the `.d.ts` crash-prevention props, so a richer contract changes their
rendered card). A re-sync therefore puts every component in the `changed` partition, and
the upload gate requires each one graded `good`. There are **no grades on this machine**;
the uploaded `_ds_sync.json` is what has been vouching for them. So shipping this means
re-capturing and hand-grading **36 authored previews** that a previous session authored and
verified — real work, and work that should be done deliberately rather than folded into an
unrelated pass. The previews and component sources are byte-identical; only the emitted
`.d.ts` and one config key moved, so this is pipeline churn, not content change.

**To ship it:** run the driver, grade the 36 sheets against this file's preview conventions
(the ink ground, the external-claims policy, the provenance-tag rules), then upload
writes-only as always. Nothing about the writes-only constraint changes.

## Re-sync run (2026-09-08 18:1x) — 41 re-verified from source commits, uploaded writes-only

`resync.mjs --remote` → build ok, diff ok, validate **exit 0**, capture ok, `anchor: "ok"`,
`learningsUnmerged: []`. Verification: **0 unchanged, 41 changed, 0 added, 0 removed**,
`pendingGrade: 36` (the 5 floor cards are never graded). Uploaded **222 files**
(220 content + sentinel + anchor), **0 deletes**. Render check **41 total, 0 bad, 0 thin,
0 variantsIdentical**.

- **⚠️ (Second checkout archived to `~/Archive/experimental-2026-09-18/MLAI-CORPORATION-WWW` on 2026-09-18; never sync from there.) THIS REPO HAS A SECOND CHECKOUT, AND IT CARRIES A TRACKED COPY OF `.design-sync/`
  POINTING AT THE SAME `projectId`.** `~/dev/active/MLAI-CORPORATION-WWW/apps/quasar-web/.design-sync/`
  has a **byte-identical `config.json` and `NOTES.md`** (both are in the durable set, so git
  carries them to every clone). Syncing from there would push *that* checkout's DS source to
  **project `6d97fa83`** — the same project this one anchors. **Always sync from
  `~/dev/active/mlai/apps/quasar-web`.** Two independent tells that this one is the working tree:
  it holds the gitignored machine state (`.cache/`, the `node_modules` fork symlink, and
  `lab-compiled.css`), and it is the canonical checkout in `~/CLAUDE.md`. The two checkouts
  are on different commits and neither has fetched the other, so they are not interchangeable.
- **Why all 41 re-verified, and why that was cheap anyway.** `keyRecipe` (7) and `scriptsSha`
  (`c0730d65e41fa758`) were **unchanged**, so this was NOT pipeline churn and produced no
  canary. Five real commits touched `src/components/**` since the 09-06 anchor
  (`419f08b`, `75e2837`, `0e2af60`, `f08203c`, `87e89e1`), moving every `sourceKey`. But
  **37 of 41 `renderHashes` were byte-identical to the anchor**, and the 4 that moved were
  exactly the floor cards (Dialog, DropdownMenu, Sheet, Tooltip) — i.e. **every graded
  component rendered pixel-identical to the render the previous sync already graded good**.
  Grading was therefore a confirmation pass over the 3 contact sheets, not a re-authoring.
  Keep this distinction: `sourceKeys` moving is a re-verify signal, `renderHashes` holding is
  the evidence that re-verification is cheap.
- **`lab-compiled.css` did NOT regenerate byte-identical this run** (`f33fea44…` → `f882f98c…`),
  and that is correct rather than the nondeterminism the 08-22 note warns about: the DS sources
  legitimately changed. `git status` on `src/components` and `src/index.css` was **clean** at
  build time — the repo's other dirty files (`src/film/*`, `package.json`, `bun.lock`) are
  outside the DS surface. **Residual caveat worth knowing:** Tailwind v4 auto-detects sources,
  so uncommitted files anywhere under `src/` can still contribute utilities to the compiled
  CSS and move `styleSha`. It adds unused classes rather than wrong ones, but if you want a
  reproducible `styleSha`, build from a clean tree.
- **The two stale items the 08-22 pass deliberately left are GONE.** Post-upload `list_files`
  shows no `components/site/LogoMark/**` and no `_preview/{Dialog,DropdownMenu,Toaster,Tooltip}.js`.
  `_preview/` now holds exactly the 36 authored components. Nothing to clean there.
- **The preserved non-repo layer is intact and was never at risk**: the plan's `deletes` was
  `[]` (the diff's `upload.deletePaths` was empty), so `_ds/**`, `preview/**`, `templates/**`,
  `ui_kits/**`, `uploads/**`, `vendor/**`, `assets/**`, `colors_and_type.css`, `SKILL.md` and
  the app-regenerated `_ds_manifest.json`/`_adherence.oxlintrc.json` all survive. The
  never-use-`components/**`-delete-globs constraint from the retarget section still stands.
- **playwright pin held**: cache has chromium 1234 and 1243, `.ds-sync` playwright pins 1243 —
  no browser download needed. (It has drifted every prior run; keep reading `browsers.json`.)
- **`[TOKENS_MISSING]` is still 5** and unchanged from 09-06. No new validate warns.
- **`conventions.md` re-validated against the fresh build: zero drift** — 36 component names,
  18 utility classes and 3 tokens all resolve. **It still does not mention `Sheet`** (same
  standing note as 09-06; deliberately not applied, the file is authored).

## Re-sync run (2026-09-16 20:1x) — stylesheet-only upload, 0 components re-verified

Invoked from the `MLAI-CORPORATION-WWW` checkout as `/design-sync MLAI Lab`; the target stayed the
pinned `6d97fa83` ("MLAI Design System") on Donald's explicit choice, and the run moved to this
checkout per the rule above (both checkouts were clean at `d856a94` = `origin/main`, so the
stale-tree hazard did not apply).

- `resync.mjs --remote` → build ok, diff ok, validate **exit 0**, capture skipped
  (`empty_worklist`), `anchor: "ok"`. **41 unchanged, 0 changed/added/removed**, `pendingGrade: []`.
  Render check (full) **41/41 clean**, same 5 floor cards. Only warn: the known `[TOKENS_MISSING]` 5.
- **`upload.any` was true with `styling: true` only.** `lab-compiled.css` moved (`f882f98c…` →
  `66f0cd59…`) because 12 commits under `apps/quasar-web/src` since 09-08 (e.g. `786ad8e`) added
  utilities; no DS source or render hash moved. Tailwind scans all of `src/`, so page-level
  commits alone are enough to require an upload. Uploaded **222 files** writes-only, **0 deletes**.
- **The local `ds-bundle/_ds_sync.json` can stand in for the fetched anchor** when the last upload
  came from this checkout: every field of the fetched `_ds_sync.json` (styleSha, auxSha,
  bundleSha12, scriptsSha, keyRecipe, sampled render/source keys, 41/41/123 counts) matched it, so
  it was copied to `.cache/remote-sync.json` instead of being hand-transcribed (see the 09-06
  malformed-sidecar trap). Compare first; never skip the comparison.
- `conventions.md` re-validated: zero drift (the only miss is the `"<this DS>"` placeholder). Still no `Sheet` line.
- `guidelines/` uploads all 7 `docs/*.md`, including `deploy-cloud-run.md` and
  `mfa-workos-runbook.md`. That is `guidelinesGlob`'s default picking up operational runbooks; the
  09-06 note already counted 7 guidelines, so they have shipped since at least then. Narrowing the glob would leave the remote copies behind
  (writes-only), so removing them is a deliberate decision, not a config tweak.

## Re-sync run (2026-09-16 21:3x) — first run under the root Bun workspace, uploaded writes-only

Run from `~/dev/active/mlai/apps/quasar-web` at `64ff43b`, right after the repo moved every app into one
root `bun.lock` with `linker = "isolated"` (PR #75) and removed five unreferenced web components.

- **Invocation needs explicit arguments.** A bare `node .ds-sync/resync.mjs --remote` exits 2 with a
  usage line. The working form is
  `node .ds-sync/resync.mjs --config .design-sync/config.json --node-modules node_modules --out ds-bundle --remote .design-sync/.cache/remote-sync.json`.
- **`.cache/remote-sync.json` had drifted from the live anchor** (styleSha `613ae027…` vs remote
  `4dfed15b…`). The fetched remote `_ds_sync.json` matched `ds-bundle/_ds_sync.json` field for field,
  so the local file was copied over the cache (old copy kept as `remote-sync.json.pre-20260917`).
- **The isolated linker silently dropped the Geist fonts.** `@import "@fontsource-variable/geist"`
  now realpaths into `<repo>/node_modules/.bun/…`, outside `apps/quasar-web`, so `extractFonts` skipped
  the five `.woff2` files and validate warned `[FONT_DANGLING]`; `_ds_bundle.css` dropped 5 faces.
  Rewriting the compiled CSS urls to the app-local symlink did not help (the converter realpaths
  too). **Fix: `extraFonts: ["node_modules/@fontsource-variable/geist/index.css"]` in
  `config.json`**, which resolves against the git workspace root. Result: 15 @font-face rules,
  5 urls rewritten to `fonts/`, all five `.woff2` shipped, no FONT warning.
- Verdict: build/diff/validate exit 0, capture skipped (`empty_worklist`), `anchor: "ok"`,
  41 unchanged, `pendingGrade: []`, render check 41/41 clean (same 5 floor cards), only warn the
  known `[TOKENS_MISSING]` 5. `upload.any` true: `FAQList` (its `.prompt.md` moved with a doc
  comment edit), bundle, styling (`lab-compiled.css` 213 → 205 KB after the component removals),
  aux.
- Uploaded writes-only: sentinel → 220 content files (same path set as 09-16) → `_ds_sync.json`,
  **0 deletes**. Remote anchor re-read after upload: `styleSha 1684af25…`, `bundleSha12
  cde194b6a3ae`, `auxSha 8d560f568b4c9ca1`, equal to local. `list_files` shows the preserved
  non-repo layer intact. Logs: `.cache/resync-20260917.log`, `.cache/upload-list-20260917.txt`.
