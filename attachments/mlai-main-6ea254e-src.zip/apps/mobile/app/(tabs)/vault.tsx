import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  View,
  StyleSheet,
  TextInput,
  RefreshControl,
  ScrollView,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import Animated, { FadeIn, FadeInDown, Layout as LayoutAnim } from "react-native-reanimated";
import { Txt, Eyebrow } from "@/components/ui/Text";
import { Surface } from "@/components/ui/Surface";
import { PressableScale } from "@/components/ui/Motion";
import { useAuth, initialsFor } from "@/lib/auth";
import {
  listItems,
  addItem,
  removeItem,
  updateItem,
  applyEdit,
  filterItems,
  getStatus,
  describeStatus,
  type VaultItem,
  type VaultStatus,
} from "@/lib/cloud";
import { color, space, accentColor, tabScrollPadding, type as t } from "@/lib/theme";
import { NoteForm } from "@/components/NoteForm";

export default function Vault() {
  const { user } = useAuth();
  const router = useRouter();
  const [items, setItems] = useState<VaultItem[]>([]);
  const [status, setStatus] = useState<VaultStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editBody, setEditBody] = useState("");
  const [savingEdit, setSavingEdit] = useState(false);
  const [query, setQuery] = useState("");
  const lifecycle = useRef({ mounted: true });
  const revision = useRef(0);
  const request = useRef(0);
  const mutations = useRef(new Set<string>());
  const [loadFailed, setLoadFailed] = useState(false);
  const [editSnapshot, setEditSnapshot] = useState<VaultItem | null>(null);

  const load = useCallback(async () => {
    const id = ++request.current;
    const version = revision.current;
    const canApply = () => lifecycle.current.mounted && id === request.current && version === revision.current && mutations.current.size === 0;
    try {
      const [s, list] = await Promise.all([getStatus(), listItems()]);
      if (canApply()) {
        setStatus(s);
        setItems(list);
        setLoadFailed(false);
        setError(null);
      }
    } catch (e) {
      if (canApply()) {
        setLoadFailed(true);
        setError(e instanceof Error ? e.message : "Could not load your vault.");
      }
    } finally {
      if (id === request.current) {
        setLoading(false);
        setRefreshing(false);
      }
    }
  }, []);

  useEffect(() => {
    const state = lifecycle.current;
    state.mounted = true;
    void load();
    return () => { state.mounted = false; };
  }, [load]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await load();
  }, [load]);

  const onAdd = useCallback(async () => {
    if (loading || !title.trim() || mutations.current.has("add")) return;
    mutations.current.add("add");
    revision.current++;
    setSaving(true);
    setError(null);
    try {
      const created = await addItem(title.trim(), body.trim());
      setItems((prev) => [created, ...prev]);
      setTitle("");
      setBody("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save to your vault.");
    } finally {
      revision.current++;
      mutations.current.delete("add");
      setSaving(false);
    }
  }, [title, body, loading]);

  const onDelete = useCallback(async (recordName: string) => {
    if (mutations.current.has(recordName)) return;
    mutations.current.add(recordName);
    revision.current++;
    setError(null);
    try {
      await removeItem(recordName);
      setItems((cur) => cur.filter((i) => i.recordName !== recordName));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not delete that item. Retry using its Delete action.");
    } finally {
      revision.current++;
      mutations.current.delete(recordName);
    }
  }, []);

  const startEdit = useCallback((item: VaultItem) => {
    if (mutations.current.size || editingId) return;
    setEditSnapshot(item);
    setEditingId(item.recordName);
    setEditTitle(item.title);
    setEditBody(item.body);
    setError(null);
  }, [editingId]);

  const cancelEdit = useCallback(() => setEditingId(null), []);

  const onSaveEdit = useCallback(
    async (item: VaultItem) => {
      const title = editTitle.trim();
      if (!title || mutations.current.has(item.recordName)) return;
      mutations.current.add(item.recordName);
      revision.current++;
      const body = editBody.trim();
      setSavingEdit(true);
      setError(null);
      try {
        const updated = await updateItem(item.recordName, title, body, item.createdAt);
        setItems((cur) => cur.some((i) => i.recordName === item.recordName)
          ? applyEdit(cur, item.recordName, updated.title, updated.body) : [updated, ...cur]);
        setEditingId(null); // close only on success — keep the form (and spinner) up during the save
      } catch (e) {
        setError(e instanceof Error ? e.message : "Could not update that item.");
      } finally {
        revision.current++;
        mutations.current.delete(item.recordName);
        setSavingEdit(false);
      }
    },
    [editTitle, editBody],
  );

  const desc = status ? describeStatus(status) : null;
  const initials = initialsFor(user);
  const visible = [...filterItems(items, query)];
  // Keep the active editor reachable even when a refresh or search omits it.
  if (editingId && !visible.some((item) => item.recordName === editingId) && editSnapshot) {
    visible.unshift(editSnapshot);
  }

  return (
    <SafeAreaView style={styles.screen} edges={["top"]}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="interactive"
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={color.wdbx} />}
      >
        {/* header */}
        <View style={styles.head}>
          <View style={styles.eyebrowRow}>
            <View style={[styles.tick, { backgroundColor: accentColor.wdbx }]} />
            <Eyebrow color={accentColor.wdbx}>Vault</Eyebrow>
          </View>
          <PressableScale
            onPress={() => router.push("/account")}
            haptic={false}
            style={styles.avatar}
            accessibilityLabel="Open account"
            accessibilityHint="Shows your identity, storage status, and sign out"
          >
            <Txt variant="mono" color={color.text}>{initials}</Txt>
          </PressableScale>
        </View>

        <Txt variant="h1" color={color.white}>Private by storage</Txt>
        <Txt variant="small" color={color.textDim} style={{ marginTop: 6 }}>
          Notes use your private iCloud when available in a native build, or encrypted local storage. Check the active storage status below.
        </Txt>

        {/* status banner */}
        {desc ? (
          <Animated.View entering={FadeIn.duration(400)} style={[styles.banner, { borderColor: (desc.ok ? accentColor.abbey : color.warn) + "44" }]}>
            <View style={[styles.dot, { backgroundColor: desc.ok ? accentColor.abbey : color.warn }]} />
            <Txt variant="small" color={color.text} style={{ flex: 1 }}>{desc.label}</Txt>
          </Animated.View>
        ) : null}

        {/* composer */}
        <Surface style={{ marginTop: space.lg }}>
          <NoteForm
            title={title}
            body={body}
            onChangeTitle={setTitle}
            onChangeBody={setBody}
            onSubmit={onAdd}
            submitLabel="SAVE TO VAULT →"
            busy={saving}
            disabled={loading}
            titleLabel="Note title"
            bodyLabel="Note body"
          />
        </Surface>

        {error ? (
          <Animated.View entering={FadeIn.duration(240)} style={styles.errorRow}>
            <View style={[styles.dot, { backgroundColor: color.warn }]} />
            <Txt variant="small" color={color.warn} style={{ flex: 1 }}>{error}</Txt>
            <PressableScale onPress={onRefresh} disabled={refreshing} accessibilityLabel="Retry loading vault">
              <Txt variant="small" color={color.warn}>Retry load</Txt>
            </PressableScale>
          </Animated.View>
        ) : null}

        {/* search */}
        {items.length > 0 ? (
          <View style={styles.search}>
            <Txt variant="mono" color={color.textMute}>⌕</Txt>
            <TextInput
              value={query}
              onChangeText={setQuery}
              placeholder="Search notes"
              placeholderTextColor={color.textFaint}
              accessibilityLabel="Search notes"
              autoCapitalize="none"
              autoCorrect={false}
              returnKeyType="search"
              style={[t.body, { flex: 1, color: color.white, paddingVertical: 0 }]}
            />
            {query ? (
              <PressableScale onPress={() => setQuery("")} haptic={false} style={styles.del} accessibilityLabel="Clear search">
                <Txt variant="mono" color={color.textMute}>✕</Txt>
              </PressableScale>
            ) : null}
          </View>
        ) : null}

        {/* list */}
        <View style={{ marginTop: space.lg, gap: space.md }}>
          {loading ? (
            <ActivityIndicator color={color.wdbx} style={{ marginTop: space.xl }} />
          ) : items.length === 0 && !editingId ? (
            <Txt variant="small" color={color.textMute} style={{ marginTop: space.md }}>
              {loadFailed ? "Vault could not be loaded. Retry to recover your notes." : "Nothing saved yet. Add your first private note above."}
            </Txt>
          ) : visible.length === 0 ? (
            <Txt variant="small" color={color.textMute} style={{ marginTop: space.md }}>
              No notes match “{query.trim()}”.
            </Txt>
          ) : (
            visible.map((item, i) => (
              <Animated.View key={item.recordName} entering={FadeInDown.delay(i * 40).duration(360)} layout={LayoutAnim}>
                <Surface accent="wdbx">
                  {editingId === item.recordName ? (
                    <NoteForm
                      title={editTitle}
                      body={editBody}
                      onChangeTitle={setEditTitle}
                      onChangeBody={setEditBody}
                      onSubmit={() => onSaveEdit(item)}
                      submitLabel="UPDATE →"
                      busy={savingEdit}
                      onCancel={cancelEdit}
                      autoFocus
                      titleLabel="Edit note title"
                      bodyLabel="Edit note body"
                    />
                  ) : (
                    <>
                      <View style={styles.rowHead}>
                        <Txt variant="h3" color={color.white} style={{ flex: 1 }}>{item.title}</Txt>
                        <PressableScale
                          onPress={() => startEdit(item)}
                          haptic={false}
                          style={styles.iconBtn}
                          accessibilityLabel={`Edit ${item.title}`}
                        >
                          <Txt variant="mono" color={color.textMute}>edit</Txt>
                        </PressableScale>
                        <PressableScale
                          onPress={() => onDelete(item.recordName)}
                          haptic
                          style={styles.del}
                          accessibilityLabel={`Delete ${item.title}`}
                        >
                          <Txt variant="mono" color={color.textMute}>✕</Txt>
                        </PressableScale>
                      </View>
                      {item.body ? (
                        <Txt variant="small" color={color.textDim} style={{ marginTop: 6 }}>{item.body}</Txt>
                      ) : null}
                      <Txt variant="mono" color={color.textFaint} style={{ marginTop: 10 }}>
                        {new Date(item.createdAt).toLocaleString()}
                      </Txt>
                    </>
                  )}
                </Surface>
              </Animated.View>
            ))
          )}
        </View>
      </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: color.ink },
  scroll: { paddingHorizontal: space.xl, paddingTop: space.md, paddingBottom: tabScrollPadding },
  head: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: space.lg },
  eyebrowRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  tick: { width: 18, height: 1.5, borderRadius: 1 },
  avatar: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: color.panel,
    borderWidth: 1,
    borderColor: color.lineStrong,
    alignItems: "center",
    justifyContent: "center",
  },
  banner: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginTop: space.lg,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: color.panel,
  },
  dot: { width: 8, height: 8, borderRadius: 4 },
  errorRow: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: space.md },
  search: {
    flexDirection: "row",
    alignItems: "center",
    gap: space.sm,
    marginTop: space.xl,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: color.line,
    backgroundColor: color.panel,
  },
  rowHead: { flexDirection: "row", alignItems: "center", gap: space.sm },
  iconBtn: { height: 28, paddingHorizontal: 10, alignItems: "center", justifyContent: "center", borderRadius: 8, backgroundColor: color.panelRaised },
  del: { width: 28, height: 28, alignItems: "center", justifyContent: "center", borderRadius: 8, backgroundColor: color.panelRaised },
});
